
public interface INotificationService {

	void AddSubscriber(INotificationObserver subscriber);
	void RemoveSubscriber(INotificationObserver subscriber);
	
void NotifySubscriber(Name name);
}
