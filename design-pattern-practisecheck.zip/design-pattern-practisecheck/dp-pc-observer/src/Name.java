
public class Name {

	String name;
	
	public Name(String name){
		this.name = name;
	}
	
	public String getName(){
		return name;
	}
}
