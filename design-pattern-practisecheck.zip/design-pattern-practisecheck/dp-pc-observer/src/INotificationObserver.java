
public interface INotificationObserver {

	void OnServerDown(Name name);
}
