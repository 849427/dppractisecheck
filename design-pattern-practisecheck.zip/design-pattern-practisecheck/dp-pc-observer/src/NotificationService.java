import java.util.*;

public class NotificationService implements INotificationService {
	
	List<INotificationObserver> subscribers = new ArrayList<INotificationObserver>();
	@Override
	public void AddSubscriber(INotificationObserver subscriber) {

		subscribers.add(subscriber);
		for(INotificationObserver observer : subscribers){
			System.out.println(observer);
		}
	}

	@Override
	public void RemoveSubscriber(INotificationObserver subscriber) {
		
		subscribers.remove(subscriber);
		for(INotificationObserver observer : subscribers){
			System.out.println(observer);
		}
	}

	@Override
	public void NotifySubscriber(Name name) {
		for(INotificationObserver o: subscribers) { 
			o.OnServerDown(name); 
			} 
		} 
	}


