
public class SteveObserver implements INotificationObserver {

	@Override
	public void OnServerDown(Name name) {
		System.out.println(name.getName());
	}

}
