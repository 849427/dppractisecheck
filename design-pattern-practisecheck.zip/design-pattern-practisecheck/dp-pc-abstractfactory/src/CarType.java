enum CarType 
{ 
    MICRO, MINI, LUXURY 
}